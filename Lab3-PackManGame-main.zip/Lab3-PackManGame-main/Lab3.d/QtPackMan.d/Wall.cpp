
#include "BoardObject.h"
#include "Wall.h"

void Wall::touch() {
    set_color(color1);
}
