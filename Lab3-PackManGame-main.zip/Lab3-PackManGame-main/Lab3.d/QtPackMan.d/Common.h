#ifndef COMMON_H
#define COMMON_H

#define SIZE_X 10
#define SIZE_Y 10

#endif
