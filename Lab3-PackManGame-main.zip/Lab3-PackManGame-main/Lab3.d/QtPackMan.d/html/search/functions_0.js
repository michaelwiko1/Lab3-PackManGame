var searchData=
[
  ['boardcells_0',['BoardCells',['../classBoardCells.html#a0f85282de14194013921b436d5e2d524',1,'BoardCells']]]
];
