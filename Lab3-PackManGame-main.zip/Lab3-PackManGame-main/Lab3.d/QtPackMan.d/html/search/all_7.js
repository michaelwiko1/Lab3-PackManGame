var searchData=
[
  ['touch_0',['touch',['../classCookie.html#a22048f68c6613b5d95c81ddc518779f7',1,'Cookie']]]
];
