var searchData=
[
  ['gamecell_0',['GameCell',['../classGameCell.html',1,'']]],
  ['get_5fvalue_1',['get_value',['../classCookie.html#ae0ec773320b4272d8189e5db71bcec3f',1,'Cookie']]]
];
