var searchData=
[
  ['myclass_0',['myClass',['../classBoardObject.html#a94d093bb880e76422aff0638ff000035',1,'BoardObject']]]
];
