var searchData=
[
  ['model_0',['Model',['../classModel.html',1,'']]],
  ['myclass_1',['myClass',['../classBoardObject.html#a94d093bb880e76422aff0638ff000035',1,'BoardObject']]]
];
